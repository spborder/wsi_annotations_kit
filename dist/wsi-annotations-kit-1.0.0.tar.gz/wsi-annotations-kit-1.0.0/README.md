# wsi_annotations_kit
utility functions for generation, conversion, and saving annotation files for various whole slide image viewers

# wsi_annotations_kit
Utility functions for generation, conversion, and saving annotation files for various whole slide image viewers

Version 1.0.0: Initial release, annotations from shapely Polygons

Version 1.0.1: Annotations generated from masks


